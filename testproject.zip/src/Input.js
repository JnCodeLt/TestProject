import React from "react";

import "./styles.css";

class Input extends React.Component {
  constructor(props) {
    super(props);

    this.handleChange = this.handleChange.bind(this);
  }

  handleChange = event => {
    const { onChange } = this.props;

    if (onChange) onChange(event.target.value);
  };

  render() {
    const { name, value, type } = this.props;

    return (
      <input
        className="input"
        name={name}
        onChange={this.handleChange}
        value={value}
        type={type}
      />
    );
  }
}

export default Input;
