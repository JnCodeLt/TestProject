import React from "react";
import ReactDOM from "react-dom";

import Input from "./Input";
import CustomTextarea from "./CustomTextarea";

import "./styles.css";

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      email: "",
      message: ""
    };
    this.handleNameChange = this.handleNameChange.bind(this);
    this.handleEmailChange = this.handleEmailChange.bind(this);
    this.handleMessageChange = this.handleMessageChange.bind(this);
  }

  handleNameChange = value => {
    this.setState({ name: value });
  };

  handleEmailChange = value => {
    this.setState({ email: value });
  };

  handleMessageChange = value => {
    this.setState({ message: value });
  };

  render() {
    const { email, name, message } = this.state;
    return (
      <div className="div">
        <form className="form">
          <Input
            name="name"
            onChange={this.handleNameChange}
            value={name}
            type="text"
          />
          <br />
          <Input
            name="email"
            onChange={this.handleEmailChange}
            type="email"
            value={email}
          />
          <br />
          <CustomTextarea
            name="message"
            onChange={this.handleMessageChange}
            type="text"
            value={message}
          />
        </form>
      </div>
    );
  }
}

ReactDOM.render(<Form />, document.getElementById("root"));

//
